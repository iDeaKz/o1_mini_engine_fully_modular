from .user import User  # Import other models as needed
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
