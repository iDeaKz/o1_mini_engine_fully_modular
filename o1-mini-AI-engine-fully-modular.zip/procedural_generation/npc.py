import random
from typing import List, Dict

class BaseNPC:
    def __init__(self, name: str) -> None:
        self.name: str = name
        self.traits: Dict[str, int] = {}
        self.skills: List[str] = []

    def __repr__(self) -> str:
        return f"{self.name} (Skills: {self.skills}, Traits: {self.traits})"

class WarriorMixin:
    def __init__(self) -> None:
        self.traits.update({"strength": random.randint(8, 10), "stamina": random.randint(5, 8)})
        self.skills.extend(["Swordsmanship", "Shield Defense"])

class MageMixin:
    def __init__(self) -> None:
        self.traits.update({"intelligence": random.randint(8, 10), "mana": random.randint(5, 8)})
        self.skills.extend(["Spellcasting", "Alchemy"])

class WarriorNPC(WarriorMixin, BaseNPC):
    def __init__(self, name: str) -> None:
        BaseNPC.__init__(self, name)
        WarriorMixin.__init__(self)

class MageNPC(MageMixin, BaseNPC):
    def __init__(self, name: str) -> None:
        BaseNPC.__init__(self, name)
        MageMixin.__init__(self)
