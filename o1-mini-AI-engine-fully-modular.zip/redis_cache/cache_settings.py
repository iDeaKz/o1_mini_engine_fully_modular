import redis
import os

class CacheConfig:
    HOST = os.getenv("REDIS_HOST", "localhost")
    PORT = int(os.getenv("REDIS_PORT", 6379))
    DB = int(os.getenv("REDIS_DB", 0))

redis_client = redis.StrictRedis(host=CacheConfig.HOST, port=CacheConfig.PORT, db=CacheConfig.DB)
