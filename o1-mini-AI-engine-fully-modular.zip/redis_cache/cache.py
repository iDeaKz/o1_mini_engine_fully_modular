import redis
import json
from typing import Dict, Optional

redis_client = redis.StrictRedis(host='localhost', port=6379, db=0, decode_responses=True)

def get_user_data(user_id: str) -> Optional[Dict[str, str]]:
    cache_key = f"user:{user_id}"
    cached_data = redis_client.get(cache_key)

    if cached_data:
        return json.loads(cached_data)

    user_data = fetch_user_from_db(user_id)
    if user_data:
        redis_client.setex(cache_key, 3600, json.dumps(user_data))
    return user_data

def fetch_user_from_db(user_id: str) -> Optional[Dict[str, str]]:
    mock_db = {
        "1234": {"name": "Alice", "level": "5"},
        "5678": {"name": "Bob", "level": "7"}
    }
    return mock_db.get(user_id)
